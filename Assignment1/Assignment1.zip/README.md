#  Assignment 1
## Files

* PSO.py: main pso algorithm
* Rastrigin.py: Rastrigin function
* Rosenbrock.py: Rosenbrock function
* Visualization.py: visualization and demo

## How to run
`python3 Visualization.py`
